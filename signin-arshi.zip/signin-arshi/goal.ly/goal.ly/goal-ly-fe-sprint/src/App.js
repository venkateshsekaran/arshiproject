import React from "react";
import axios from "axios";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Sign_in from "./Sign_in";
import Forgetpassword from "./Forgetpassword";
import Navbar from "./Navbar";

function App() {
  return (
    <>
      {/* <BrowserRouter> */}

      <Navbar />
      <Routes>
        <Route path="/Sign-in" element={<Sign_in />} />
        <Route path="/forget" element={<Forgetpassword />} />
      </Routes>
      {/* </BrowserRouter> */}
      {/* <Login />
      <Sign_in /> */}
      {/* <Navbar /> */}
    </>
  );
}
export default App;
