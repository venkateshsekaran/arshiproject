import React from "react";
import { Link } from "react-router-dom";
function Navbar() {
  return (
    <div>
      <nav className="navbar navbar-dark bg-dark navbar-expand-lg">
        <div className="ml-auto">
          <ul className="navbar-nav">
            <li className="nav-list">
              <Link to="./Sign-in" className="nav-link">
                signin
              </Link>
            </li>
            <li className="nav-list">
              <Link to="./forget" className="nav-link">
                forget
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
