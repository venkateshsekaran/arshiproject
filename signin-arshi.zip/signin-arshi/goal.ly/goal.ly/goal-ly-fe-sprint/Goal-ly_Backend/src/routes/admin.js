const express = require('express');
const userController = require('../controllers/user.controller');

const router = express.Router();

//= ===============================
// Admin routes
//= ===============================
router.get('/allusers', userController.allusers);

module.exports = router;