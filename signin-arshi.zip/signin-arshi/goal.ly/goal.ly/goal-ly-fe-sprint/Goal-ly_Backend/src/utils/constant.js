module.exports = Object.freeze({
  TABLE_USER: 'users',
  DATATYPE_TIMESTAMP: 'TIMESTAMP'
});