import React from "react";
import axios from "axios";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Sign_in from "./components/Sign_in";
// import Navbar from "./components/Navbar";

function App() {
  return (
    <>
      {/* <BrowserRouter> */}
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/Sign-in" element={<Sign_in />} />
      </Routes>
      {/* </BrowserRouter> */}
      {/* <Login />
      <Sign_in /> */}
      {/* <Navbar /> */}
    </>
  );
}
export default App;
