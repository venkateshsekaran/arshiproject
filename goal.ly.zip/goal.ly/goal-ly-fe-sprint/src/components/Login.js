import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Eye } from "heroicons-react";
import { EyeOff } from "heroicons-react";
// import Navbar from "./Navbar";
import validator from "validator";
const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [passwordType, setPasswordType, setPasswordInput] =
    useState("password");
  let BtnRfc = useRef();
  let enbbtn = (event) => {
    let flg = event.target.checked;
    BtnRfc.current.disabled = !flg;
  };
  const handlePasswordChange = (evnt) => {
    setPassword(evnt.target.value);
  };
  const togglePassword = (e) => {
    e.preventDefault();
    if (passwordType === "password") {
      setPasswordType("text");
      return;
    }
    setPasswordType("password");
  };
  return (
    <div className="min-h-full flex items-center justify-center py-10 px-0 my-5 sm:px-6 lg:px-8 min-h-screen flex flex-col">
      <div className="max-w-md w-full space-y8 bg-white px-7 py-9 rounded shadow-md">
        <div>
          <h1 className="mt-6 text-3xl font-semibold font-extrabold text-gray-900">
            Welcome
          </h1>
        </div>
        <div>
          <form className="mt-8 space-y-6" action="#" method="POST">
            <div>
              <input
                className="apperence-none rounded-none outline-inherit 
              rounded relative block w-full px-3 py-3 border border-b-neutral-900 
              rounded-t-md focus:outline-none focus:ring-indigo-50  focus:z-10 
              sm:text-sm outline:none placeholder:italic placeholder:text-slate-400 "
                type="email"
                id="email"
                name="email"
                value={username}
                placeholder="Enter UserName or Email"
                onChange={(e) => setUsername(e.target.value)}
                pattern="/^[a-zA-Z0-9]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/"
              />
            </div>
            <div className="py-2 relative">
              <input
                className="apperence-none rounded-none rounded relative block 
              w-full px-2.5 py-3 border border-b-neutral-900 rounded-t-md 
              focus:outline-none focus:ring-indigo-500 focus:z-10 sm:text-sm  
              outline:none placeholder:italic placeholder:text-slate-400 "
                type={passwordType}
                name="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Please Enter Password"
                pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#^@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
              />
              <div className="absolute inset-y-0 right-2 top-5 items-center text-sm z-10">
                <button onClick={(e) => togglePassword(e)}>
                  {passwordType === "password" ? <EyeOff /> : <Eye />}
                </button>
              </div>
            </div>
            <div className="flex justify-between">
              <div className="text-center">
                <input type="checkbox" onChange={enbbtn} id="checkbox" />
                <label className="pl-3 text-sm font-sans">Remember me</label>
              </div>
              <div>
                <Link
                  to="/"
                  className="text-sm bg-black-800 font-sans font-semibold"
                >
                  {" "}
                  Forgot Password?
                </Link>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <div>
                <Link
                  to="/"
                  className="text-green-500 text-center capitalize font-ml
                font-bold"
                >
                  {" "}
                  Create Account
                </Link>
              </div>
              <div>
                <button
                  className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
                  type="submit"
                  ref={BtnRfc}
                  disabled
                  id="submit"
                  name="submitBtn"
                >
                  Sign in
                </button>
              </div>
            </div>

            <div className="border-t-2 border-black-100 border-b-2 border-black-100">
              <div className="py-2">
                <Link to="/" className="text-sm text-center">
                  SIGN IN WITH SSO
                </Link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
export default Login;
