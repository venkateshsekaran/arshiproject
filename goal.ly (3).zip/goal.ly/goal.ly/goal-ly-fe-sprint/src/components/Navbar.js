import React from "react";

export default function Navbar({ fixed }) {
  const [navbarOpen, setNavbarOpen] = React.useState(false);
  return (
    <>
      <nav className="relative flex flex-wrap items-center justify-between px-2 py-3 bg-gray-500 ">
        <div className="container px-4 mx-auto flex flex-wrap items-center justify-between">
          <div className="w-full relative flex justify-between lg:w-auto lg:static lg:block lg:justify-start">
            <a
              className="text-sm font-bold leading-relaxed inline-block mr-4 py-2 whitespace-nowrap uppercase text-white"
              href="#pablo"
            ></a>
            <button
              className="text-white cursor-pointer text-xl leading-none px-3 py-1 border border-solid border-transparent rounded bg-transparent block lg:hidden outline-none focus:outline-none"
              type="button"
              onClick={() => setNavbarOpen(!navbarOpen)}
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
          <div
            className={
              "lg:flex flex-grow items-center" +
              (navbarOpen ? " flex" : " hidden")
            }
            id="example-navbar-danger"
          >
            <ul className="flex flex-col lg:flex-row list-none lg:ml-auto">
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-facebook-square text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">DASHBOARD</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">REPORTS</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-pinterest text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">SCREENCASTS</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">EDIT</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2  py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">SETTING</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">INVITE</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">DOWNLOAD</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <nav className="relative flex flex-wrap items-center justify-between px-2 py-3 bg-gray-500 mb-3">
        <div className="container px-4 mx-auto flex flex-wrap items-center justify-between">
          <div className="w-full relative flex justify-between lg:w-auto lg:static lg:block lg:justify-start">
            <a
              className="text-sm font-bold leading-relaxed inline-block mr-4 py-2 whitespace-nowrap uppercase text-white"
              href="#pablo"
            ></a>
            <button
              className="text-white cursor-pointer text-xl leading-none px-3 py-1 border border-solid border-transparent rounded bg-transparent block lg:hidden outline-none focus:outline-none"
              type="button"
              onClick={() => setNavbarOpen(!navbarOpen)}
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
          <div
            className={
              "lg:flex flex-grow items-center" +
              (navbarOpen ? " flex" : " hidden")
            }
            id="example-navbar-danger"
          >
            <ul className="flex flex-col lg:flex-row list-none lg:ml-auto">
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-facebook-square text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">DASHBOARD</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">REPORTS</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-pinterest text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">SCREENCASTS</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">EDIT</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2  py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">SETTING</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">INVITE</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="px-2 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75"
                  href="#pablo"
                >
                  <i className="fab fa-twitter text-lg leading-lg text-white opacity-75"></i>
                  <span className="ml-2">DOWNLOAD</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div className="container mx-auto mt-5">Overview</div>
      <div className="  grid grid-cols-5 gap-0  container mx-auto d-flex mt-5 flex  ">
        <div className="  max-w-sm rounded overflow-hidden shadow-sm h-48 lg:h- lg:96 w-48  ">
          01
        </div>
        <div className="  max-w-sm rounded overflow-hidden shadow-sm h-48 lg:h-lg:96 w-48">
          02
        </div>
        <div className="  max-w-sm rounded overflow-hidden shadow-sm h-48 lg:h- lg:96 w-48">
          03
        </div>
        <div className="  max-w-sm rounded overflow-hidden shadow-sm h-48 lg:h- lg:96 w-48">
          04
        </div>
        <div className="  max-w-sm rounded overflow-hidden shadow-sm h-48 lg:h- lg:96 w-48">
          05
        </div>
      </div>
      <div className="container mt-3">
        <div className="row">
          <div className="  grid grid-cols-2  container mx-auto mt-5   ">
            <div className=" ml-auto max-w-2xl rounded overflow-hidden shadow-lg h-56 lg:h- lg:96 w-96 ">
              <div className="mx-auto  px-5 py-5 ">Top Projects</div>
            </div>
            <div className=" ml-3  max-w-sm rounded overflow-hidden shadow-lg h-56 lg:h- lg:96 w-96 ">
              hello
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
