const express = require ('express');

const userController = require ('../controllers/user.controller');

const router = express.Router();

//= ===============================
// API routes
//= ===============================
router.get('/me', function(req, res){userController.profile(req, res)});
router.post('/changePassword',function(req, res){
  userController.changePassword(req, res)
});

module.exports = router;