const express = require('express');
const userController = require('../controllers/user.controller');
const router = express.Router();

//= ===============================
// Public routes
//= ===============================

router.post('/login',function(req, res){
    userController.login(req, res)
  });
router.post('/register',function(req, res){
    userController.register(req, res)
  });

module.exports = router;