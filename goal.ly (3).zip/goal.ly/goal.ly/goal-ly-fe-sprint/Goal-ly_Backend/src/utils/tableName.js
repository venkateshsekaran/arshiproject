module.exports = Object.freeze({
  TABLE_USER: 'users',
});