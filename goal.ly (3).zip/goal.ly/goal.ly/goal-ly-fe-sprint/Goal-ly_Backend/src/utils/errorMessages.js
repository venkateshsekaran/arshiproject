module.exports = Object.freeze({
  USER_NOT_FOUND : "User is not found",
  INCORRECT_TOKEN : "Incorrect token is provided, try re-login",
  NOT_ADMIN : 'You don\'t have admin access'
});