const express = require('express');
const dotenv = require('dotenv');
const publicRoutes = require ('./src/routes/public');
const apiRoutes = require('./src/routes/api')
const adminRoutes = require('./src/routes/admin')
const adminMiddleware = require('./src/middleware/adminAuth')
const apiMiddleware = require ('./src/middleware/apiAuth');
const bodyParser = require('body-parser');
const cors = require('cors');
require('./src/config/sequelize');

dotenv.config();

const app = express();
app.use(
  bodyParser.urlencoded({
    extended: true,
  }),
);
// Cors options
// var corsOptions = {
//   origin: process.env.APP_PORT
// };
// app.use(cors(corsOptions));
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

app.use('/pub', publicRoutes);
app.use('/api', apiMiddleware, apiRoutes);
app.use('/api/admin', apiMiddleware, adminMiddleware, adminRoutes);

module.exports = app;