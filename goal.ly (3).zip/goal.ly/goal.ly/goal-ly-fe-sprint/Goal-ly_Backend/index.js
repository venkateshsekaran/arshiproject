const app = require('./app');
const dotenv = require('dotenv');
app.get('/', function (req, res) {
  res.send('Health root');
});

const setUpExpress = () => {
  dotenv.config({ path: '.env' });
  const port = process.env.APP_PORT || 3001;
  app.listen(port, () => {
    console.log(`App running on port ${port}...`);
  });
};
setUpExpress()