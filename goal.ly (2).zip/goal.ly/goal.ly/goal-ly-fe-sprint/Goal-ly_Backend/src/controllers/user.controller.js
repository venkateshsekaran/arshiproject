const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { users } = require ('../models/index');
const { successResponse,errorResponse, uniqueId } = require('../helpers/index');

//Get All users
 const allusers = async (req, res) => {
  try {
    const page = req.params.page || 1;
    const limit = 2;
    const user = await users.findAndCountAll({
      order: [['createdAt', 'DESC'], ['name', 'ASC']],
      offset: (page - 1) * limit,
      limit,
    });
    return successResponse(req, res, { user });
  } catch (error) {
    return errorResponse(req, res, error.message);
  }
};

// Register
 const register = async (req, res) => {
  try {
    const {
      email, password, name,
    } = req.body;
    const user = await users.findOne({
      where: { email },
    });
    if (user) {
      throw new Error('users already exists with same email');
    }
    const reqPass = crypto
      .createHash('md5')
      .update(password)
      .digest('hex');
    const payload = {
      email,
      name,
      password: reqPass,
      isVerified: false,
    };

    const newusers = await users.create(payload);
    return successResponse(req, res, {});
  } catch (error) {
    return errorResponse(req, res, error.message);
  }
};

//Login
 const login = async (req, res) => {
  try {
    const user = await users.scope('withSecretColumns').findOne({
      where: { email: req.body.email },
    });
    if (!user) {
      throw new Error('Incorrect Email Id/Password');
    }
    const reqPass = crypto
      .createHash('md5')
      .update(req.body.password || '')
      .digest('hex');
    if (reqPass !== user.password) {
      throw new Error('Incorrect Email Id/Password');
    }
    const token = jwt.sign(
      {
        user: {
          userId: user.id,
          email: user.email,
          createdAt: new Date(),
        },
      },
      process.env.SECRET,
    );
    delete user.dataValues.password;
    return successResponse(req, res, { user, token });
  } catch (error) {
    return errorResponse(req, res, error.message);
  }
};

// Get single user profile
 const profile = async (req, res) => {
  try {
    const { userId } = req.user;
    const user = await users.findOne({ where: { id: userId } });
    return successResponse(req, res, { user });
  } catch (error) {
    return errorResponse(req, res, error.message);
  }
};

//Change password
 const changePassword = async (req, res) => {
  try {
    const { userId } = req.user;
    const user = await users.scope('withSecretColumns').findOne({
      where: { id: userId },
    });

    const reqPass = crypto
      .createHash('md5')
      .update(req.body.oldPassword)
      .digest('hex');
    if (reqPass !== user.password) {
      throw new Error('Old password is incorrect');
    }

    const newPass = crypto
      .createHash('md5')
      .update(req.body.newPassword)
      .digest('hex');

    await users.update({ password: newPass }, { where: { id: user.id } });
    return successResponse(req, res, {});
  } catch (error) {
    return errorResponse(req, res, error.message);
  }
};
module.exports = {
  allusers: allusers,
  register: register,
  login: login,
  profile: profile,
  changePassword: changePassword
};